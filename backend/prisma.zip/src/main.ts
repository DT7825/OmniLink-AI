import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.useGlobalPipes(
  new ValidationPipe({
    whitelist: true,
    forbidNonWhitelisted: true,
    transform: true,
  }),
);

  const config = new DocumentBuilder()
    .setTitle('OmniLink AI API')
    .setDescription(
      'AI-powered Humanitarian Assistance Platform API Documentation',
    )
    .setVersion('1.0')
    .addBearerAuth()
    .build();

  const document = SwaggerModule.createDocument(app, config);

  SwaggerModule.setup('api/docs', app, document);

  app.enableCors();

  await app.listen(process.env.PORT ?? 3000);

  console.log(
    `🚀 OmniLink AI Backend Running: http://localhost:${process.env.PORT ?? 3000}`,
  );

  console.log(
    `📘 Swagger Documentation: http://localhost:${process.env.PORT ?? 3000}/api/docs`,
  );
}

bootstrap();
